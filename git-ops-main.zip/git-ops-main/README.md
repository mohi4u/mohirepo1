# git-ops
basic tutorial for git &amp; git hub
