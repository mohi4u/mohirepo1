# project-work 1 & 2
SimpliLearn Projects 1 &amp; Project 2
