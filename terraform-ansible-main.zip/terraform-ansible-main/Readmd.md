
# AWS Terraform Infra Creation
- Step 1: Clone the repo
- git clone https://github.com/manikcloud/terraform-ansible
- Step 2: Launch your AWS lab in SL 
- https://faculty.lms.simplilearn.com/courses/4040/-PG-DO---DevOps-Certification-Training/practice-labs
- Step 3: Goto IAM & Create a user 
- https://us-east-1.console.aws.amazon.com/iamv2/home?region=us-east-1#/home
- Step 4: Add the Admin Access to this user and 
- Step 5: Download the key file 
- Step 6: Run aws configure 
- Step 7: put the keys

- Step 8: run this command ``` aws s3 ls
- Step 9: terraform --version
