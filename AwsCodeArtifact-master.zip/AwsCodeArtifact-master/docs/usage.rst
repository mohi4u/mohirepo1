=====
Usage
=====

To use NotebookC in a project:

Import your file and call the function.
    .. code:: python

    from notebookc import notebookc

    notebookc.convert("Jeff Hale")
