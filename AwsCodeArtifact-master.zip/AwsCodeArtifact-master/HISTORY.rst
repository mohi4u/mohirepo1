=======
History
=======

0.0.1 (2019-02-20)
------------------

* First release on PyPI.
