# manik-notebookc
===========

Convert a Jupyter Notebook to a Python script or HTML file in your Python program.

For more details please visit:
https://medium.com/@varunmanik1/aws-codeartifact-npm-pypi-twine-django-demo-project-11aae763f80d
